/**
 * HealthSync - Main Application Logic
 * Implements real-world routing, booking workflow, accessibility tools,
 * search/filter engine, appointment management, notifications, and local persistence.
 */

// Global State
const state = {
  currentScreen: 'home',
  doctors: [...INITIAL_DOCTORS],
  appointments: JSON.parse(localStorage.getItem('healthsync_appointments')) || INITIAL_APPOINTMENTS,
  notifications: JSON.parse(localStorage.getItem('healthsync_notifications')) || INITIAL_NOTIFICATIONS,
  healthRecords: JSON.parse(localStorage.getItem('healthsync_records')) || INITIAL_HEALTH_RECORDS,
  userProfile: JSON.parse(localStorage.getItem('healthsync_profile')) || USER_PROFILE,
  
  // Active Filters & Selections
  selectedSpeciality: 'All',
  searchQuery: '',
  filterLocation: 'All',
  filterExperience: 'All',
  
  // Booking in progress
  currentBookingDoctor: null,
  selectedDate: 'Sat, 28 Aug',
  selectedTime: '10:30 AM',
  selectedVisitType: 'Clinic Visit',
  bookingReason: 'Routine check-up',
  
  // Last confirmed booking
  lastBooking: null,

  // Accessibility state
  accessibility: {
    largeText: localStorage.getItem('hs_acc_large_text') === 'true',
    readingSpace: localStorage.getItem('hs_acc_reading_space') === 'true',
    readAloud: false,
    voiceControl: false
  },
  darkMode: localStorage.getItem('hs_dark_mode') === 'true'
};

// Available dates for booking carousel
const BOOKING_DATES = [
  { day: 'Today', date: '25', month: 'Aug', full: 'Wed, 25 Aug 2026' },
  { day: 'Thu', date: '26', month: 'Aug', full: 'Thu, 26 Aug 2026' },
  { day: 'Fri', date: '27', month: 'Aug', full: 'Fri, 27 Aug 2026' },
  { day: 'Sat', date: '28', month: 'Aug', full: 'Sat, 28 Aug 2026' },
  { day: 'Sun', date: '29', month: 'Aug', full: 'Sun, 29 Aug 2026' },
  { day: 'Mon', date: '30', month: 'Aug', full: 'Mon, 30 Aug 2026' },
  { day: 'Tue', date: '31', month: 'Aug', full: 'Tue, 31 Aug 2026' }
];

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  initThemeAndAccessibility();
  initNavigation();
  initSearch();
  initModalsAndDropdowns();
  initVoiceFeatures();
  
  // Set default doctor for profile/booking
  state.currentBookingDoctor = state.doctors.find(d => d.id === 'dr-gayathri') || state.doctors[0];
  
  // Render initial screen
  navigateTo('home');
  renderNotifications();
});

// ============================================================
// NAVIGATION & ROUTING
// ============================================================
function navigateTo(screenId, params = {}) {
  state.currentScreen = screenId;
  
  // Close any mobile sidebar
  const sidebar = document.getElementById('sidebar');
  if (sidebar) sidebar.classList.remove('open-mobile');

  // Update nav item active styling
  document.querySelectorAll('.sidebar-nav-list .nav-link').forEach(link => {
    link.classList.remove('active');
  });

  const matchingNav = document.querySelector(`.nav-link[data-screen="${screenId}"]`);
  if (matchingNav) {
    matchingNav.classList.add('active');
  } else if (screenId === 'doctor-profile' || screenId === 'search-doctor') {
    const docNav = document.querySelector('.nav-link[data-screen="search-doctor"]');
    if (docNav) docNav.classList.add('active');
  } else if (screenId === 'book-appointment' || screenId === 'appointment-confirmation' || screenId === 'appointment-history') {
    const aptNav = document.querySelector('.nav-link[data-screen="appointment-history"]');
    if (aptNav) aptNav.classList.add('active');
  }

  // Hide all screens, show target
  document.querySelectorAll('.screen-view').forEach(screen => {
    screen.classList.remove('active');
  });

  const targetScreen = document.getElementById(`screen-${screenId}`);
  if (targetScreen) {
    targetScreen.classList.add('active');
  }

  // Screen specific renders
  if (screenId === 'home') {
    renderHomeScreen();
  } else if (screenId === 'search-doctor') {
    renderDoctorList();
  } else if (screenId === 'doctor-profile') {
    if (params.doctorId) {
      state.currentBookingDoctor = state.doctors.find(d => d.id === params.doctorId) || state.currentBookingDoctor;
    }
    renderDoctorProfile(state.currentBookingDoctor);
  } else if (screenId === 'book-appointment') {
    if (params.doctorId) {
      state.currentBookingDoctor = state.doctors.find(d => d.id === params.doctorId) || state.currentBookingDoctor;
    }
    renderBookAppointmentScreen();
  } else if (screenId === 'appointment-confirmation') {
    renderAppointmentConfirmation();
  } else if (screenId === 'appointment-history') {
    renderAppointmentHistory();
  } else if (screenId === 'health-records') {
    renderHealthRecords();
  } else if (screenId === 'profile') {
    renderUserProfile();
  }

  // Scroll content to top
  const appContent = document.getElementById('app-content');
  if (appContent) appContent.scrollTo({ top: 0, behavior: 'smooth' });

  // Read aloud if enabled
  if (state.accessibility.readAloud) {
    speakPageTitle();
  }
}

function initNavigation() {
  // Sidebar links
  document.querySelectorAll('.nav-link[data-screen]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const screen = btn.getAttribute('data-screen');
      navigateTo(screen);
    });
  });

  // Mobile menu toggle button
  const menuToggle = document.getElementById('menuToggleBtn');
  const sidebar = document.getElementById('sidebar');
  if (menuToggle && sidebar) {
    menuToggle.addEventListener('click', () => {
      sidebar.classList.toggle('open-mobile');
    });
  }

  // Accessibility accordion toggle in sidebar
  const accToggleBtn = document.getElementById('accAccordionToggle');
  const accDrawer = document.getElementById('accessibilityDrawer');
  if (accToggleBtn && accDrawer) {
    accToggleBtn.addEventListener('click', () => {
      accToggleBtn.classList.toggle('open');
      accDrawer.classList.toggle('open');
    });
  }

  // Brand Logo click
  const brandLogo = document.getElementById('brandLogo');
  if (brandLogo) {
    brandLogo.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo('home');
    });
  }
}

// ============================================================
// SCREEN 1: HOME SCREEN LOGIC
// ============================================================
function renderHomeScreen() {
  // Update upcoming appointment banner
  const nextApptContainer = document.getElementById('homeNextAppointmentCard');
  if (nextApptContainer && state.appointments.upcoming.length > 0) {
    const next = state.appointments.upcoming[0];
    nextApptContainer.innerHTML = `
      <div class="summary-card-content">
        <h4>Next Appointment</h4>
        <div class="date-badge">${next.date}</div>
        <div class="detail-line">${next.time}</div>
        <div class="detail-line">${next.doctorName}</div>
        <div class="sub-detail">${next.speciality}</div>
      </div>
      <div class="summary-icon-right">
        <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
          <line x1="16" y1="2" x2="16" y2="6"></line>
          <line x1="8" y1="2" x2="8" y2="6"></line>
          <line x1="3" y1="10" x2="21" y2="10"></line>
        </svg>
      </div>
    `;
    nextApptContainer.onclick = () => navigateTo('appointment-history');
  }

  // Find Doctor button in hero banner
  const heroFindDocBtn = document.getElementById('heroFindDoctorBtn');
  if (heroFindDocBtn) {
    heroFindDocBtn.onclick = () => navigateTo('search-doctor');
  }

  // Quick Actions cards
  const qaSearchDoc = document.getElementById('qaSearchDoc');
  if (qaSearchDoc) qaSearchDoc.onclick = () => navigateTo('search-doctor');

  const qaBookApt = document.getElementById('qaBookApt');
  if (qaBookApt) qaBookApt.onclick = () => navigateTo('search-doctor');

  const qaHealthRec = document.getElementById('qaHealthRec');
  if (qaHealthRec) qaHealthRec.onclick = () => navigateTo('health-records');

  const qaNewRecord = document.getElementById('qaNewRecord');
  if (qaNewRecord) qaNewRecord.onclick = () => openUploadModal();

  // View All links
  const viewAllApt = document.getElementById('viewAllAppointmentsLink');
  if (viewAllApt) viewAllApt.onclick = () => navigateTo('appointment-history');

  const medsCard = document.getElementById('homeMedicationsCard');
  if (medsCard) {
    medsCard.onclick = () => {
      showToast('Medication list: 1) Atorvastatin 10mg, 2) Vitamin D3, 3) CoQ10', 'info');
    };
  }
}

// ============================================================
// SCREEN 2: SEARCH DOCTOR SCREEN
// ============================================================
function renderDoctorList() {
  const container = document.getElementById('doctorsListContainer');
  if (!container) return;

  // Filter doctors
  let filtered = state.doctors.filter(doc => {
    const matchesSpeciality = state.selectedSpeciality === 'All' || 
      doc.speciality.toLowerCase() === state.selectedSpeciality.toLowerCase();
    
    const matchesSearch = !state.searchQuery || 
      doc.name.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
      doc.speciality.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
      doc.hospital.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
      doc.specializations.some(s => s.toLowerCase().includes(state.searchQuery.toLowerCase()));

    const matchesLocation = state.filterLocation === 'All' || doc.location === state.filterLocation;
    
    return matchesSpeciality && matchesSearch && matchesLocation;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="padding: 40px; text-align: center; background: var(--card-white); border-radius: var(--radius-md); border: 1.5px dashed var(--border-light);">
        <p style="font-weight: 700; font-size: 1.1rem; color: var(--text-muted); margin-bottom: 8px;">No doctors found matching your criteria.</p>
        <p style="color: var(--text-light); font-size: 0.9rem;">Try selecting a different speciality or clearing your search keywords.</p>
        <button class="btn-primary-teal" style="margin-top: 14px;" onclick="resetDoctorFilters()">Reset Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(doc => `
    <div class="doctor-card-item" onclick="openDoctorProfile('${doc.id}')">
      <div class="doctor-item-left">
        <div class="doctor-avatar-circle">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
        </div>
        <div class="doctor-info-text">
          <h4 class="doc-name">${doc.name}</h4>
          <p class="doc-speciality">${doc.speciality}</p>
          <p class="doc-hospital">${doc.hospital}</p>
        </div>
      </div>
      <div class="doctor-item-right">
        <div>
          <div class="doc-rating-badge">
            <span class="star-gold">★</span> ${doc.rating} (${doc.reviewsCount} reviews)
          </div>
          <div class="doc-exp-badge">
            <span>💼</span> ${doc.experience}
          </div>
        </div>
        <span class="chevron-nav-btn">&gt;</span>
      </div>
    </div>
  `).join('');

  // Setup Speciality pills click handlers
  document.querySelectorAll('.speciality-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-speciality') === state.selectedSpeciality);
    pill.onclick = () => {
      state.selectedSpeciality = pill.getAttribute('data-speciality');
      renderDoctorList();
    };
  });
}

function resetDoctorFilters() {
  state.selectedSpeciality = 'All';
  state.searchQuery = '';
  state.filterLocation = 'All';
  const searchInput = document.getElementById('topSearchInput');
  if (searchInput) searchInput.value = '';
  renderDoctorList();
}

function openDoctorProfile(doctorId) {
  state.currentBookingDoctor = state.doctors.find(d => d.id === doctorId) || state.doctors[0];
  navigateTo('doctor-profile', { doctorId });
}

// ============================================================
// SCREEN 3: DOCTOR PROFILE SCREEN
// ============================================================
function renderDoctorProfile(doctor) {
  if (!doctor) doctor = state.doctors[0];
  state.currentBookingDoctor = doctor;

  const container = document.getElementById('doctorProfileContainer');
  if (!container) return;

  const reviewsHtml = doctor.reviews.map(rev => `
    <div class="patient-review-card">
      <div class="reviewer-avatar">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
          <circle cx="12" cy="7" r="4"></circle>
        </svg>
      </div>
      <div class="reviewer-info">
        <h4 class="reviewer-name">${rev.author}</h4>
        <div class="review-stars">${'★'.repeat(rev.rating)}${'☆'.repeat(5 - rev.rating)}</div>
        <p class="review-comment">"${rev.comment}"</p>
      </div>
    </div>
  `).join('');

  container.innerHTML = `
    <!-- Top Hero Card -->
    <div class="doctor-profile-card">
      <div class="profile-top-row">
        <div class="profile-left-main">
          <div class="profile-avatar-large">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
          </div>
          <div class="profile-details-title">
            <h2>${doctor.name}</h2>
            <div class="profile-spec">${doctor.speciality}</div>
            <div style="font-size: 0.92rem; font-weight: 700; color: var(--text-main);">
              <span class="star-gold">★</span> ${doctor.rating} (${doctor.reviewsCount} reviews)
            </div>
          </div>
        </div>
        <div>
          <button class="btn-primary-teal" id="profileBookAptBtn" onclick="navigateTo('book-appointment', { doctorId: '${doctor.id}' })">
            Book Appointment
          </button>
        </div>
      </div>

      <!-- 3 Stats Badges -->
      <div class="profile-stats-grid">
        <div class="profile-stat-box">
          <div class="stat-box-left">
            <div class="stat-label">Experience</div>
            <div class="stat-value">${doctor.experience}</div>
          </div>
          <div class="stat-box-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="16" y1="13" x2="8" y2="13"></line>
              <line x1="16" y1="17" x2="8" y2="17"></line>
              <polyline points="10 9 9 9 8 9"></polyline>
            </svg>
          </div>
        </div>

        <div class="profile-stat-box">
          <div class="stat-box-left">
            <div class="stat-label">Consultation Fees</div>
            <div class="stat-value">${doctor.fees}</div>
          </div>
          <div class="stat-box-icon" style="font-weight: 800; font-size: 24px;">$</div>
        </div>

        <div class="profile-stat-box">
          <div class="stat-box-left">
            <div class="stat-label">Language</div>
            <div class="stat-value">${doctor.languages}</div>
          </div>
          <div class="stat-box-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="2" y1="12" x2="22" y2="12"></line>
              <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
            </svg>
          </div>
        </div>
      </div>
    </div>

    <!-- About Doctor -->
    <div class="profile-content-section">
      <h3 class="section-subtitle-heading">About Doctor</h3>
      <p class="profile-about-text">${doctor.fullExperience}</p>
    </div>

    <!-- Specializations -->
    <div class="profile-content-section">
      <h3 class="section-subtitle-heading">Specializations</h3>
      <div class="specializations-tag-row">
        ${doctor.specializations.map(spec => `<span class="spec-tag-badge">${spec}</span>`).join('')}
      </div>
    </div>

    <!-- Patient Reviews -->
    <div class="profile-content-section">
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <h3 class="section-subtitle-heading">Patient Reviews</h3>
        <button class="btn-outline-teal" style="padding: 6px 14px; font-size: 0.85rem;" onclick="openAddReviewModal()">+ Add Review</button>
      </div>
      ${reviewsHtml}
    </div>
  `;
}

// ============================================================
// SCREEN 4: BOOK APPOINTMENT SCREEN
// ============================================================
function renderBookAppointmentScreen() {
  const doctor = state.currentBookingDoctor || state.doctors[0];
  
  // Render Left Selected Doctor Card
  const leftCard = document.getElementById('bookingSelectedDocCard');
  if (leftCard) {
    leftCard.innerHTML = `
      <div class="selected-doc-avatar">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
          <circle cx="12" cy="7" r="4"></circle>
        </svg>
      </div>
      <h3 class="selected-doc-name">${doctor.name}</h3>
      <div class="selected-doc-spec">${doctor.speciality}</div>
      <div class="selected-doc-fee">Consultation Fee: ${doctor.fees}</div>
    `;
  }

  // Render Date Cards Carousel
  const datesContainer = document.getElementById('bookingDatesContainer');
  if (datesContainer) {
    datesContainer.innerHTML = BOOKING_DATES.map((item, index) => {
      const isSelected = item.full.includes(state.selectedDate) || index === 3;
      return `
        <div class="date-select-card ${isSelected ? 'selected' : ''}" onclick="selectBookingDate('${item.full}', this)">
          <span class="day-label">${item.day}</span>
          <span class="date-number">${item.date}</span>
          <span class="month-label">${item.month}</span>
        </div>
      `;
    }).join('');
  }

  // Setup Time slot buttons
  document.querySelectorAll('.time-slot-pill').forEach(pill => {
    pill.classList.toggle('selected', pill.textContent.trim() === state.selectedTime);
    pill.onclick = () => {
      document.querySelectorAll('.time-slot-pill').forEach(p => p.classList.remove('selected'));
      pill.classList.add('selected');
      state.selectedTime = pill.textContent.trim();
    };
  });

  // Setup Visit Type buttons
  const clinicBtn = document.getElementById('btnVisitClinic');
  const videoBtn = document.getElementById('btnVisitVideo');
  if (clinicBtn && videoBtn) {
    clinicBtn.onclick = () => {
      clinicBtn.classList.add('active');
      videoBtn.classList.remove('active');
      state.selectedVisitType = 'Clinic Visit';
    };
    videoBtn.onclick = () => {
      videoBtn.classList.add('active');
      clinicBtn.classList.remove('active');
      state.selectedVisitType = 'Video Call';
    };
  }

  // Confirm Booking Button
  const confirmBtn = document.getElementById('btnConfirmBooking');
  if (confirmBtn) {
    confirmBtn.onclick = handleBookingSubmit;
  }
}

function selectBookingDate(dateFull, element) {
  document.querySelectorAll('.date-select-card').forEach(c => c.classList.remove('selected'));
  element.classList.add('selected');
  state.selectedDate = dateFull;
}

function scrollBookingDates(direction) {
  const container = document.getElementById('bookingDatesContainer');
  if (container) {
    container.scrollBy({ left: direction * 150, behavior: 'smooth' });
  }
}

function handleBookingSubmit() {
  const doctor = state.currentBookingDoctor || state.doctors[0];
  const reasonInput = document.getElementById('bookingReasonInput');
  const reasonText = reasonInput && reasonInput.value.trim() ? reasonInput.value.trim() : 'Routine check-up';
  
  // Format readable appointment record
  const newAppointment = {
    id: 'apt-' + Date.now(),
    doctorId: doctor.id,
    doctorName: doctor.name,
    speciality: doctor.speciality,
    hospital: doctor.hospital,
    rating: `${doctor.rating} (${doctor.reviewsCount} reviews)`,
    date: state.selectedDate || 'Sat, 28 Aug 2026',
    time: state.selectedTime || '10:30 AM',
    type: state.selectedVisitType === 'Clinic Visit' ? 'In-clinic visit' : 'Video Consultation',
    reason: reasonText,
    status: 'Confirmed',
    canReschedule: true,
    canCancel: true
  };

  // Prepend to upcoming appointments
  state.appointments.upcoming.unshift(newAppointment);
  localStorage.setItem('healthsync_appointments', JSON.stringify(state.appointments));
  
  // Add notification
  const newNotif = {
    id: 'notif-' + Date.now(),
    title: 'Appointment Booked',
    message: `Appointment confirmed with ${doctor.name} on ${newAppointment.date} at ${newAppointment.time}.`,
    time: 'Just now',
    unread: true,
    icon: 'calendar'
  };
  state.notifications.unshift(newNotif);
  localStorage.setItem('healthsync_notifications', JSON.stringify(state.notifications));
  renderNotifications();

  // Save last booking state
  state.lastBooking = newAppointment;

  // Show Toast
  showToast(`Appointment booked successfully with ${doctor.name}!`, 'success');

  // Navigate to confirmation screen
  navigateTo('appointment-confirmation');
}

// ============================================================
// SCREEN 5: APPOINTMENT CONFIRMATION SCREEN
// ============================================================
function renderAppointmentConfirmation() {
  const apt = state.lastBooking || state.appointments.upcoming[0] || {
    doctorName: 'Dr.Gayathri',
    speciality: 'Cardiologist',
    hospital: 'Apollo Hospital,Chennai',
    rating: '4.9 (400 reviews)',
    date: 'Sat , 24 May 2026',
    time: '10:30 AM',
    type: 'In-clinic visit',
    reason: 'Routine check-up'
  };

  const container = document.getElementById('confirmationContainer');
  if (!container) return;

  container.innerHTML = `
    <!-- Success Alert Banner -->
    <div class="success-alert-banner">
      <div class="success-check-circle">✓</div>
      <div class="success-banner-text">
        <h3>Appointment Booked!</h3>
        <p>Your appointment has been confirmed successfully.</p>
      </div>
    </div>

    <!-- Details Two-Col Grid -->
    <div class="confirmation-two-col">
      <!-- Left Column: Doctor Card & Security Badge -->
      <div>
        <div class="confirmed-doc-card">
          <div class="confirmed-doc-avatar">
            <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
          </div>
          <h3 style="font-size: 1.25rem; font-weight: 800; margin-bottom: 4px;">${apt.doctorName}</h3>
          <p style="font-size: 0.92rem; color: var(--primary-teal); font-weight: 600; margin-bottom: 2px;">${apt.speciality}</p>
          <p style="font-size: 0.85rem; color: var(--text-light); margin-bottom: 8px;">${apt.hospital}</p>
          <div style="font-size: 0.9rem; font-weight: 700; color: var(--text-main);">
            <span class="star-gold">★</span> ${apt.rating}
          </div>
        </div>

        <div class="security-badge-card">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
          </svg>
          <span>Your health data is secure</span>
        </div>
      </div>

      <!-- Right Column: Appointment Details List -->
      <div class="confirmed-details-container">
        <h4 class="details-list-title">Appointment details</h4>
        
        <div class="detail-row-item">
          <div class="detail-row-left">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
            <span>Date</span>
          </div>
          <div class="detail-row-value">${apt.date}</div>
        </div>

        <div class="detail-row-item">
          <div class="detail-row-left">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"></circle>
              <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
            <span>Time</span>
          </div>
          <div class="detail-row-value">${apt.time}</div>
        </div>

        <div class="detail-row-item">
          <div class="detail-row-left">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
              <circle cx="12" cy="10" r="3"></circle>
            </svg>
            <span>Visit Type</span>
          </div>
          <div class="detail-row-value">${apt.type}</div>
        </div>

        <div class="detail-row-item">
          <div class="detail-row-left">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
            </svg>
            <span>Reason for visit</span>
          </div>
          <div class="detail-row-value">${apt.reason || 'Routine check-up'}</div>
        </div>

        <div class="confirmation-actions-row">
          <button class="btn-outline-teal" onclick="navigateTo('home')">Back Home</button>
          <button class="btn-primary-teal" onclick="navigateTo('appointment-history')">View Appointment</button>
        </div>
      </div>
    </div>
  `;
}

// ============================================================
// SCREEN 6: APPOINTMENT HISTORY SCREEN
// ============================================================
function renderAppointmentHistory() {
  const container = document.getElementById('appointmentHistoryContainer');
  if (!container) return;

  const upcomingList = state.appointments.upcoming;
  const pastList = state.appointments.past;

  let upcomingHtml = '';
  if (upcomingList.length === 0) {
    upcomingHtml = `
      <div style="background: var(--card-white); padding: 24px; border-radius: var(--radius-md); border: 1px dashed var(--border-light); text-align: center; color: var(--text-muted);">
        No upcoming appointments scheduled.
        <button class="btn-primary-teal" style="display: block; margin: 12px auto 0;" onclick="navigateTo('search-doctor')">Book an Appointment</button>
      </div>
    `;
  } else {
    upcomingHtml = upcomingList.map(apt => `
      <div class="history-card-upcoming" id="card-${apt.id}">
        <div class="history-card-top">
          <div class="history-doc-left">
            <div class="history-avatar-sm">
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
            </div>
            <div>
              <h4 style="font-size: 1.15rem; font-weight: 700; color: var(--text-main);">${apt.doctorName}</h4>
              <p style="font-size: 0.88rem; color: var(--text-muted);">${apt.speciality} &bull; ${apt.hospital}</p>
            </div>
          </div>
          <div class="status-confirmed-badge">
            ● Confirmed &gt;
          </div>
        </div>

        <div class="history-card-bottom">
          <div class="appointment-meta-row">
            <span>📅 ${apt.date}</span>
            <span>🕒 ${apt.time}</span>
            <span>📍 ${apt.type}</span>
          </div>
          <div class="history-actions-group">
            <button class="btn-reschedule" onclick="openRescheduleModal('${apt.id}')">
              📅 Reschedule
            </button>
            <button class="btn-cancel" onclick="confirmCancelAppointment('${apt.id}')">
              🗑️ Cancel
            </button>
          </div>
        </div>
      </div>
    `).join('');
  }

  const pastHtml = pastList.map(apt => {
    const isCompleted = apt.status === 'Completed';
    return `
      <div class="past-appointment-item">
        <div class="history-doc-left">
          <div class="history-avatar-sm" style="background-color: #f1f5f9;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
          </div>
          <div>
            <h4 style="font-size: 1.05rem; font-weight: 700;">${apt.doctorName}</h4>
            <p style="font-size: 0.86rem; color: var(--text-muted);">${apt.speciality} &bull; ${apt.hospital}</p>
          </div>
        </div>

        <div class="past-meta-col">
          <div class="past-date-time">${apt.date} &nbsp;|&nbsp; ${apt.time} &nbsp;|&nbsp; ${apt.type}</div>
          <div class="${isCompleted ? 'status-completed-badge' : 'status-cancelled-badge'}">
            ● ${apt.status} &gt;
          </div>
        </div>
      </div>
    `;
  }).join('');

  container.innerHTML = `
    <!-- Top Filter & Tabs Row -->
    <div class="history-controls-row">
      <div class="history-tabs-group">
        <button class="history-tab-btn active" id="tabUpcomingBtn" onclick="switchHistoryTab('upcoming')">Upcoming</button>
        <button class="history-tab-btn" id="tabPastBtn" onclick="switchHistoryTab('past')">Past</button>
      </div>
      <div>
        <button class="filter-action-btn" onclick="openFilterModal()">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon>
          </svg>
          Filter
        </button>
      </div>
    </div>

    <!-- Upcoming Section -->
    <div class="history-section-block" id="historyUpcomingSection">
      <h3 class="history-section-heading">Upcoming Appointments</h3>
      ${upcomingHtml}
    </div>

    <!-- Past Section -->
    <div class="history-section-block" id="historyPastSection">
      <h3 class="history-section-heading">Past Appointments</h3>
      ${pastHtml}
    </div>
  `;
}

function switchHistoryTab(tab) {
  const upBtn = document.getElementById('tabUpcomingBtn');
  const pastBtn = document.getElementById('tabPastBtn');
  const upSec = document.getElementById('historyUpcomingSection');
  const pastSec = document.getElementById('historyPastSection');

  if (tab === 'upcoming') {
    upBtn.classList.add('active');
    pastBtn.classList.remove('active');
    upSec.style.display = 'block';
    pastSec.style.display = 'none';
  } else {
    pastBtn.classList.add('active');
    upBtn.classList.remove('active');
    upSec.style.display = 'none';
    pastSec.style.display = 'block';
  }
}

function confirmCancelAppointment(appointmentId) {
  const apt = state.appointments.upcoming.find(a => a.id === appointmentId);
  if (!apt) return;

  if (confirm(`Are you sure you want to cancel your appointment with ${apt.doctorName} on ${apt.date}?`)) {
    // Remove from upcoming
    state.appointments.upcoming = state.appointments.upcoming.filter(a => a.id !== appointmentId);
    
    // Add to past as Cancelled
    state.appointments.past.unshift({
      id: 'apt-cancelled-' + Date.now(),
      doctorName: apt.doctorName,
      speciality: apt.speciality,
      hospital: apt.hospital,
      date: apt.date,
      time: apt.time,
      type: apt.type,
      status: 'Cancelled'
    });

    localStorage.setItem('healthsync_appointments', JSON.stringify(state.appointments));
    showToast('Appointment successfully cancelled.', 'danger');
    renderAppointmentHistory();
  }
}

function openRescheduleModal(appointmentId) {
  const apt = state.appointments.upcoming.find(a => a.id === appointmentId);
  if (!apt) return;

  const modalBody = document.getElementById('genericModalBody');
  const modalTitle = document.getElementById('genericModalTitle');
  
  modalTitle.textContent = `Reschedule Appointment: ${apt.doctorName}`;
  modalBody.innerHTML = `
    <div style="margin-bottom: 16px;">
      <p style="font-size: 0.92rem; color: var(--text-muted); margin-bottom: 12px;">Choose a new date and time slot for your consultation.</p>
      <div class="form-field" style="margin-bottom: 12px;">
        <label>Select New Date</label>
        <select id="rescheduleDateSelect" class="search-input" style="height: 40px; padding: 0 12px;">
          <option value="Tue, 01 Sep 2026">Tue, 01 Sep 2026</option>
          <option value="Wed, 02 Sep 2026">Wed, 02 Sep 2026</option>
          <option value="Thu, 03 Sep 2026">Thu, 03 Sep 2026</option>
          <option value="Fri, 04 Sep 2026">Fri, 04 Sep 2026</option>
        </select>
      </div>
      <div class="form-field">
        <label>Select New Time</label>
        <select id="rescheduleTimeSelect" class="search-input" style="height: 40px; padding: 0 12px;">
          <option value="09:30 AM">09:30 AM</option>
          <option value="11:00 AM">11:00 AM</option>
          <option value="02:30 PM">02:30 PM</option>
          <option value="04:30 PM">04:30 PM</option>
          <option value="06:00 PM">06:00 PM</option>
        </select>
      </div>
    </div>
  `;

  const modalFooter = document.getElementById('genericModalFooter');
  modalFooter.innerHTML = `
    <button class="btn-outline-teal" onclick="closeModal()">Cancel</button>
    <button class="btn-primary-teal" onclick="saveRescheduledAppointment('${apt.id}')">Save Changes</button>
  `;

  openModal();
}

function saveRescheduledAppointment(appointmentId) {
  const dateSelect = document.getElementById('rescheduleDateSelect');
  const timeSelect = document.getElementById('rescheduleTimeSelect');

  const apt = state.appointments.upcoming.find(a => a.id === appointmentId);
  if (apt && dateSelect && timeSelect) {
    apt.date = dateSelect.value;
    apt.time = timeSelect.value;
    localStorage.setItem('healthsync_appointments', JSON.stringify(state.appointments));
    closeModal();
    showToast(`Appointment rescheduled to ${apt.date} at ${apt.time}`, 'success');
    renderAppointmentHistory();
  }
}

// ============================================================
// HEALTH RECORDS SCREEN
// ============================================================
function renderHealthRecords() {
  const container = document.getElementById('healthRecordsContainer');
  if (!container) return;

  container.innerHTML = `
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
      <div>
        <h2 class="page-title" style="margin-bottom: 4px;">Health Records</h2>
        <p style="color: var(--text-muted); font-size: 0.92rem;">Safely manage and review all your medical files, lab tests, and prescriptions.</p>
      </div>
      <button class="btn-primary-teal" onclick="openUploadModal()">
        + Upload Record
      </button>
    </div>

    <div class="records-grid">
      ${state.healthRecords.map(rec => `
        <div class="record-card">
          <div class="record-card-top">
            <div class="record-icon-badge">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
              </svg>
            </div>
            <div class="record-details">
              <h4>${rec.title}</h4>
              <p style="color: var(--primary-teal); font-weight: 600;">${rec.doctor} &bull; ${rec.hospital}</p>
              <p style="margin-top: 6px;">${rec.summary}</p>
              <div style="margin-top: 8px; font-size: 0.8rem; color: var(--text-light);">
                <span>Date: ${rec.date}</span> &bull; <span>Size: ${rec.size}</span>
              </div>
            </div>
          </div>
          <div style="display: flex; justify-content: flex-end; gap: 8px;">
            <button class="btn-outline-teal" style="padding: 6px 14px; font-size: 0.85rem;" onclick="viewRecordDetails('${rec.id}')">View</button>
            <button class="btn-primary-teal" style="padding: 6px 14px; font-size: 0.85rem;" onclick="downloadRecordSim('${rec.title}')">Download PDF</button>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

function viewRecordDetails(recordId) {
  const rec = state.healthRecords.find(r => r.id === recordId);
  if (!rec) return;

  const modalBody = document.getElementById('genericModalBody');
  const modalTitle = document.getElementById('genericModalTitle');
  modalTitle.textContent = rec.title;
  modalBody.innerHTML = `
    <div style="font-size: 0.95rem; line-height: 1.6;">
      <p><strong>Doctor:</strong> ${rec.doctor}</p>
      <p><strong>Hospital:</strong> ${rec.hospital}</p>
      <p><strong>Date of Record:</strong> ${rec.date}</p>
      <p><strong>Category:</strong> ${rec.category}</p>
      <hr style="margin: 14px 0; border: none; border-top: 1px solid var(--border-light);" />
      <p><strong>Clinical Notes:</strong></p>
      <p style="background: var(--body-bg); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-light); margin-top: 6px;">${rec.summary}</p>
    </div>
  `;
  const modalFooter = document.getElementById('genericModalFooter');
  modalFooter.innerHTML = `
    <button class="btn-primary-teal" onclick="closeModal()">Close</button>
  `;
  openModal();
}

function downloadRecordSim(title) {
  showToast(`Downloading "${title}.pdf"...`, 'info');
}

function openUploadModal() {
  const modalBody = document.getElementById('genericModalBody');
  const modalTitle = document.getElementById('genericModalTitle');
  modalTitle.textContent = 'Upload Health Record';
  modalBody.innerHTML = `
    <div class="form-field" style="margin-bottom: 12px;">
      <label>Record Title</label>
      <input type="text" id="uploadRecordTitle" placeholder="e.g. Thyroid Panel Report" />
    </div>
    <div class="form-field" style="margin-bottom: 12px;">
      <label>Doctor / Clinic</label>
      <input type="text" id="uploadRecordDoctor" placeholder="e.g. Apollo Hospital" />
    </div>
    <div class="form-field" style="margin-bottom: 12px;">
      <label>Category</label>
      <select id="uploadRecordCategory">
        <option value="Lab Reports">Lab Reports</option>
        <option value="Prescriptions">Prescriptions</option>
        <option value="Vaccinations">Vaccinations</option>
        <option value="Discharge Summary">Discharge Summary</option>
      </select>
    </div>
    <div class="form-field">
      <label>File Attachment</label>
      <input type="file" id="uploadRecordFile" style="padding-top: 8px;" />
    </div>
  `;
  const modalFooter = document.getElementById('genericModalFooter');
  modalFooter.innerHTML = `
    <button class="btn-outline-teal" onclick="closeModal()">Cancel</button>
    <button class="btn-primary-teal" onclick="saveUploadedRecord()">Upload Now</button>
  `;
  openModal();
}

function saveUploadedRecord() {
  const titleInput = document.getElementById('uploadRecordTitle');
  const docInput = document.getElementById('uploadRecordDoctor');
  const catInput = document.getElementById('uploadRecordCategory');

  if (!titleInput.value.trim()) {
    showToast('Please provide a record title.', 'danger');
    return;
  }

  const newRec = {
    id: 'rec-' + Date.now(),
    title: titleInput.value.trim(),
    doctor: docInput.value.trim() || 'Apollo Hospital',
    hospital: 'Chennai',
    date: 'Today, ' + new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
    category: catInput.value,
    type: 'PDF Document',
    size: '1.2 MB',
    summary: 'Document uploaded by patient. Verified by HealthSync portal.'
  };

  state.healthRecords.unshift(newRec);
  localStorage.setItem('healthsync_records', JSON.stringify(state.healthRecords));
  closeModal();
  showToast('Record uploaded successfully!', 'success');
  renderHealthRecords();
}

// ============================================================
// PROFILE SCREEN
// ============================================================
function renderUserProfile() {
  const container = document.getElementById('userProfileContainer');
  if (!container) return;

  const prof = state.userProfile;
  container.innerHTML = `
    <div class="profile-card-container">
      <div class="profile-user-hero">
        <div class="profile-hero-avatar">
          ${prof.name.charAt(0).toUpperCase()}
        </div>
        <div>
          <h2 style="font-size: 1.6rem; font-weight: 800; margin-bottom: 2px;">${prof.fullName}</h2>
          <p style="color: var(--primary-teal); font-weight: 600;">@${prof.name} &bull; ${prof.city}</p>
          <p style="color: var(--text-muted); font-size: 0.88rem; margin-top: 4px;">HealthSync Patient ID: #HS-9824</p>
        </div>
      </div>

      <div class="form-grid-2col" style="margin-bottom: 24px;">
        <div class="form-field">
          <label>Full Name</label>
          <input type="text" id="profFullName" value="${prof.fullName}" />
        </div>
        <div class="form-field">
          <label>Email Address</label>
          <input type="email" id="profEmail" value="${prof.email}" />
        </div>
        <div class="form-field">
          <label>Phone Number</label>
          <input type="tel" id="profPhone" value="${prof.phone}" />
        </div>
        <div class="form-field">
          <label>Blood Group</label>
          <input type="text" id="profBlood" value="${prof.bloodGroup}" />
        </div>
        <div class="form-field">
          <label>Height</label>
          <input type="text" id="profHeight" value="${prof.height}" />
        </div>
        <div class="form-field">
          <label>Weight</label>
          <input type="text" id="profWeight" value="${prof.weight}" />
        </div>
        <div class="form-field" style="grid-column: span 2;">
          <label>Emergency Contact</label>
          <input type="text" id="profEmergency" value="${prof.emergencyContact}" />
        </div>
        <div class="form-field" style="grid-column: span 2;">
          <label>Known Allergies</label>
          <input type="text" id="profAllergies" value="${prof.allergies}" />
        </div>
      </div>

      <div style="display: flex; justify-content: flex-end; gap: 12px;">
        <button class="btn-outline-teal" onclick="navigateTo('home')">Cancel</button>
        <button class="btn-primary-teal" onclick="saveProfileChanges()">Save Profile Details</button>
      </div>
    </div>
  `;
}

function saveProfileChanges() {
  state.userProfile.fullName = document.getElementById('profFullName').value.trim();
  state.userProfile.email = document.getElementById('profEmail').value.trim();
  state.userProfile.phone = document.getElementById('profPhone').value.trim();
  state.userProfile.bloodGroup = document.getElementById('profBlood').value.trim();
  state.userProfile.height = document.getElementById('profHeight').value.trim();
  state.userProfile.weight = document.getElementById('profWeight').value.trim();
  state.userProfile.emergencyContact = document.getElementById('profEmergency').value.trim();
  state.userProfile.allergies = document.getElementById('profAllergies').value.trim();

  localStorage.setItem('healthsync_profile', JSON.stringify(state.userProfile));
  showToast('Profile information updated successfully!', 'success');
}

// ============================================================
// THEME & ACCESSIBILITY ENGINES
// ============================================================
function initThemeAndAccessibility() {
  // Apply saved Dark Mode
  if (state.darkMode) {
    document.body.classList.add('dark-mode');
  }

  const darkToggleBtn = document.getElementById('darkModeToggleBtn');
  if (darkToggleBtn) {
    darkToggleBtn.addEventListener('click', () => {
      state.darkMode = !state.darkMode;
      document.body.classList.toggle('dark-mode', state.darkMode);
      localStorage.setItem('hs_dark_mode', state.darkMode);
      showToast(state.darkMode ? 'Dark theme enabled' : 'Light theme enabled', 'info');
    });
  }

  // Accessibility Switches
  const toggleLargeText = document.getElementById('toggleLargeText');
  const toggleReadingSpace = document.getElementById('toggleReadingSpace');
  const toggleReadAloud = document.getElementById('toggleReadAloud');
  const toggleVoiceControl = document.getElementById('toggleVoiceControl');

  if (toggleLargeText) {
    toggleLargeText.checked = state.accessibility.largeText;
    document.body.classList.toggle('accessibility-large-text', state.accessibility.largeText);
    toggleLargeText.addEventListener('change', (e) => {
      state.accessibility.largeText = e.target.checked;
      document.body.classList.toggle('accessibility-large-text', state.accessibility.largeText);
      localStorage.setItem('hs_acc_large_text', state.accessibility.largeText);
      showToast(state.accessibility.largeText ? 'Large text enabled' : 'Default text restored', 'info');
    });
  }

  if (toggleReadingSpace) {
    toggleReadingSpace.checked = state.accessibility.readingSpace;
    document.body.classList.toggle('accessibility-reading-space', state.accessibility.readingSpace);
    toggleReadingSpace.addEventListener('change', (e) => {
      state.accessibility.readingSpace = e.target.checked;
      document.body.classList.toggle('accessibility-reading-space', state.accessibility.readingSpace);
      localStorage.setItem('hs_acc_reading_space', state.accessibility.readingSpace);
      showToast(state.accessibility.readingSpace ? 'Enhanced reading spacing on' : 'Standard spacing restored', 'info');
    });
  }

  if (toggleReadAloud) {
    toggleReadAloud.addEventListener('change', (e) => {
      state.accessibility.readAloud = e.target.checked;
      if (state.accessibility.readAloud) {
        showToast('Screen reader mode enabled', 'info');
        speakText('Screen reader mode activated for HealthSync.');
      } else {
        if ('speechSynthesis' in window) window.speechSynthesis.cancel();
        showToast('Screen reader mode disabled', 'info');
      }
    });
  }

  if (toggleVoiceControl) {
    toggleVoiceControl.addEventListener('change', (e) => {
      state.accessibility.voiceControl = e.target.checked;
      const voiceBar = document.getElementById('voiceAssistantBar');
      if (voiceBar) {
        voiceBar.classList.toggle('active', state.accessibility.voiceControl);
      }
      if (state.accessibility.voiceControl) {
        startVoiceListener();
      }
    });
  }
}

// Text to Speech
function speakText(text) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1.0;
  utterance.pitch = 1.0;
  window.speechSynthesis.speak(utterance);
}

function speakPageTitle() {
  const currentView = document.querySelector('.screen-view.active');
  if (currentView) {
    const heading = currentView.querySelector('h1, h2, h3');
    if (heading) {
      speakText('Showing ' + heading.innerText);
    }
  }
}

// Voice Control & Speech Recognition
function initVoiceFeatures() {
  const micBtn = document.getElementById('searchMicBtn');
  if (micBtn) {
    micBtn.addEventListener('click', () => {
      startVoiceSearch();
    });
  }

  const voiceCloseBtn = document.getElementById('voiceCloseBtn');
  if (voiceCloseBtn) {
    voiceCloseBtn.addEventListener('click', () => {
      const toggleVoice = document.getElementById('toggleVoiceControl');
      if (toggleVoice) toggleVoice.checked = false;
      state.accessibility.voiceControl = false;
      document.getElementById('voiceAssistantBar').classList.remove('active');
    });
  }
}

function startVoiceSearch() {
  const micBtn = document.getElementById('searchMicBtn');
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    if (micBtn) micBtn.classList.add('active-listening');
    showToast('Listening... Speak a doctor name or speciality.', 'info');

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      const searchInput = document.getElementById('topSearchInput');
      if (searchInput) searchInput.value = transcript;
      state.searchQuery = transcript;
      navigateTo('search-doctor');
      renderDoctorList();
      showToast(`Searching for "${transcript}"`, 'info');
      if (micBtn) micBtn.classList.remove('active-listening');
    };

    recognition.onerror = () => {
      if (micBtn) micBtn.classList.remove('active-listening');
      showToast('Could not hear audio. You can type in the search bar.', 'info');
    };

    recognition.onend = () => {
      if (micBtn) micBtn.classList.remove('active-listening');
    };
  } else {
    // Simulated voice search for browsers without SpeechRecognition
    const sampleQueries = ['Cardiologist', 'Dr Priya', 'Apollo Hospital', 'Gynecologist'];
    const randomQuery = sampleQueries[Math.floor(Math.random() * sampleQueries.length)];
    const searchInput = document.getElementById('topSearchInput');
    if (searchInput) searchInput.value = randomQuery;
    state.searchQuery = randomQuery;
    navigateTo('search-doctor');
    renderDoctorList();
    showToast(`Voice input detected: "${randomQuery}"`, 'info');
  }
}

function startVoiceListener() {
  const statusElem = document.getElementById('voiceStatusText');
  if (statusElem) statusElem.textContent = 'Voice assistant ready. Say "Home", "Doctors", or "Appointments"...';
  speakText('HealthSync voice assistant is listening.');
}

function triggerSimulatedVoiceCommand(command) {
  const statusElem = document.getElementById('voiceStatusText');
  if (statusElem) statusElem.textContent = `Heard: "${command}"`;
  
  if (command.toLowerCase().includes('home')) {
    navigateTo('home');
  } else if (command.toLowerCase().includes('doctor')) {
    navigateTo('search-doctor');
  } else if (command.toLowerCase().includes('appointment')) {
    navigateTo('appointment-history');
  } else if (command.toLowerCase().includes('record')) {
    navigateTo('health-records');
  }
}

// ============================================================
// SEARCH ENGINE
// ============================================================
function initSearch() {
  const searchInput = document.getElementById('topSearchInput');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value.trim();
      if (state.currentScreen !== 'search-doctor' && state.searchQuery.length > 0) {
        navigateTo('search-doctor');
      } else {
        renderDoctorList();
      }
    });

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        navigateTo('search-doctor');
        renderDoctorList();
      }
    });
  }
}

// ============================================================
// NOTIFICATIONS & MODALS
// ============================================================
function initModalsAndDropdowns() {
  // Notification Bell Toggle
  const notifBtn = document.getElementById('notificationBellBtn');
  const notifPanel = document.getElementById('notificationsPanel');

  if (notifBtn && notifPanel) {
    notifBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      notifPanel.classList.toggle('active');
    });
  }

  // Close panels on document click
  document.addEventListener('click', (e) => {
    if (notifPanel && !notifPanel.contains(e.target) && e.target !== notifBtn) {
      notifPanel.classList.remove('active');
    }
  });

  // User Profile Pill click
  const userPill = document.getElementById('userProfilePill');
  if (userPill) {
    userPill.addEventListener('click', () => {
      navigateTo('profile');
    });
  }

  // Modal close buttons
  const modalClose = document.getElementById('modalCloseBtn');
  const modalOverlay = document.getElementById('genericModalOverlay');
  if (modalClose) modalClose.addEventListener('click', closeModal);
  if (modalOverlay) {
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeModal();
    });
  }
}

function renderNotifications() {
  const listContainer = document.getElementById('notificationsListContainer');
  const badgeDot = document.getElementById('notifBadgeDot');

  const unreadCount = state.notifications.filter(n => n.unread).length;
  if (badgeDot) {
    badgeDot.style.display = unreadCount > 0 ? 'block' : 'none';
  }

  if (listContainer) {
    listContainer.innerHTML = state.notifications.map(n => `
      <div class="notification-item ${n.unread ? 'unread' : ''}" onclick="markNotificationRead('${n.id}')">
        <div style="color: var(--primary-teal); font-size: 18px; margin-top: 2px;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
        </div>
        <div>
          <h5 style="font-size: 0.92rem; font-weight: 700; color: var(--text-main); margin-bottom: 2px;">${n.title}</h5>
          <p style="font-size: 0.84rem; color: var(--text-muted); line-height: 1.3;">${n.message}</p>
          <span style="font-size: 0.75rem; color: var(--text-light); margin-top: 4px; display: block;">${n.time}</span>
        </div>
      </div>
    `).join('');
  }
}

function markNotificationRead(id) {
  const notif = state.notifications.find(n => n.id === id);
  if (notif) {
    notif.unread = false;
    localStorage.setItem('healthsync_notifications', JSON.stringify(state.notifications));
    renderNotifications();
  }
}

function clearAllNotifications() {
  state.notifications.forEach(n => n.unread = false);
  localStorage.setItem('healthsync_notifications', JSON.stringify(state.notifications));
  renderNotifications();
  showToast('All notifications marked as read', 'info');
}

// Generic Modal Helpers
function openModal() {
  const modal = document.getElementById('genericModalOverlay');
  if (modal) modal.classList.add('active');
}

function closeModal() {
  const modal = document.getElementById('genericModalOverlay');
  if (modal) modal.classList.remove('active');
}

// Filter Modal
function openFilterModal(focusedField = 'all') {
  const modalBody = document.getElementById('genericModalBody');
  const modalTitle = document.getElementById('genericModalTitle');
  modalTitle.textContent = 'Filter Doctors';
  modalBody.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 14px;">
      <div class="form-field">
        <label>Speciality</label>
        <select id="filterSpecialitySelect">
          <option value="All" ${state.selectedSpeciality === 'All' ? 'selected' : ''}>All Specialities</option>
          <option value="Cardiologist" ${state.selectedSpeciality === 'Cardiologist' ? 'selected' : ''}>Cardiologist</option>
          <option value="General Physician" ${state.selectedSpeciality === 'General Physician' ? 'selected' : ''}>General Physician</option>
          <option value="Gynecologist" ${state.selectedSpeciality === 'Gynecologist' ? 'selected' : ''}>Gynecologist</option>
          <option value="Neurologist" ${state.selectedSpeciality === 'Neurologist' ? 'selected' : ''}>Neurologist</option>
          <option value="Dermatologist" ${state.selectedSpeciality === 'Dermatologist' ? 'selected' : ''}>Dermatologist</option>
          <option value="Pediatrics" ${state.selectedSpeciality === 'Pediatrics' ? 'selected' : ''}>Pediatrics</option>
        </select>
      </div>

      <div class="form-field">
        <label>Location / Hospital</label>
        <select id="filterHospitalSelect">
          <option value="All">All Locations & Hospitals</option>
          <option value="Apollo Hospital,Chennai">Apollo Hospital, Chennai</option>
          <option value="City Care Hospital, Chennai">City Care Hospital, Chennai</option>
          <option value="Children's Clinic, Chennai">Children's Clinic, Chennai</option>
        </select>
      </div>

      <div class="form-field">
        <label>Minimum Experience</label>
        <select id="filterExpSelect">
          <option value="All">Any Experience</option>
          <option value="5">5+ Years</option>
          <option value="7">7+ Years</option>
          <option value="8">8+ Years</option>
          <option value="10">10+ Years</option>
        </select>
      </div>

      <div class="form-field">
        <label>Consultation Fee Range (Up to $600)</label>
        <input type="range" id="filterFeeRange" min="200" max="600" step="50" value="600" />
        <div style="display: flex; justify-content: space-between; font-size: 0.8rem; color: var(--text-light); margin-top: 4px;">
          <span>$200</span>
          <span id="feeRangeValue" style="font-weight: 700; color: var(--primary-teal);">$600</span>
        </div>
      </div>
    </div>
  `;

  const feeRange = document.getElementById('filterFeeRange');
  const feeValue = document.getElementById('feeRangeValue');
  if (feeRange && feeValue) {
    feeRange.addEventListener('input', (e) => {
      feeValue.textContent = `$${e.target.value}`;
    });
  }

  const modalFooter = document.getElementById('genericModalFooter');
  modalFooter.innerHTML = `
    <button class="btn-outline-teal" onclick="resetDoctorFilters(); closeModal();">Reset</button>
    <button class="btn-primary-teal" onclick="applyFiltersModal()">Apply Filter</button>
  `;
  openModal();

  if (focusedField === 'speciality') {
    document.getElementById('filterSpecialitySelect')?.focus();
  } else if (focusedField === 'location') {
    document.getElementById('filterHospitalSelect')?.focus();
  } else if (focusedField === 'experience') {
    document.getElementById('filterExpSelect')?.focus();
  }
}

function applyFiltersModal() {
  const speciality = document.getElementById('filterSpecialitySelect').value;
  const hospital = document.getElementById('filterHospitalSelect').value;
  const expStr = document.getElementById('filterExpSelect').value;
  const maxFee = parseInt(document.getElementById('filterFeeRange').value, 10);
  
  state.selectedSpeciality = speciality;
  state.doctors = INITIAL_DOCTORS.filter(d => {
    const matchSpec = speciality === 'All' || d.speciality.toLowerCase() === speciality.toLowerCase();
    const matchHospital = hospital === 'All' || d.hospital.includes(hospital);
    const matchFee = d.feeAmount <= maxFee;
    
    let matchExp = true;
    if (expStr !== 'All') {
      const minYears = parseInt(expStr, 10);
      const docYears = parseInt(d.experience, 10) || 0;
      matchExp = docYears >= minYears;
    }

    return matchSpec && matchHospital && matchFee && matchExp;
  });

  closeModal();
  renderDoctorList();
  showToast('Filters applied successfully', 'success');
}

// Add Review Modal
function openAddReviewModal() {
  const modalBody = document.getElementById('genericModalBody');
  const modalTitle = document.getElementById('genericModalTitle');
  modalTitle.textContent = `Write a Review for ${state.currentBookingDoctor.name}`;
  modalBody.innerHTML = `
    <div class="form-field" style="margin-bottom: 12px;">
      <label>Your Name</label>
      <input type="text" id="reviewAuthorInput" value="${state.userProfile.fullName}" />
    </div>
    <div class="form-field" style="margin-bottom: 12px;">
      <label>Rating</label>
      <select id="reviewRatingSelect">
        <option value="5">★★★★★ (5 Stars - Excellent)</option>
        <option value="4">★★★★☆ (4 Stars - Very Good)</option>
        <option value="3">★★★☆☆ (3 Stars - Average)</option>
      </select>
    </div>
    <div class="form-field">
      <label>Your Feedback</label>
      <textarea id="reviewTextInput" class="form-textarea" placeholder="Share your experience with the doctor..."></textarea>
    </div>
  `;

  const modalFooter = document.getElementById('genericModalFooter');
  modalFooter.innerHTML = `
    <button class="btn-outline-teal" onclick="closeModal()">Cancel</button>
    <button class="btn-primary-teal" onclick="saveNewReview()">Submit Review</button>
  `;
  openModal();
}

function saveNewReview() {
  const author = document.getElementById('reviewAuthorInput').value.trim();
  const rating = parseInt(document.getElementById('reviewRatingSelect').value, 10);
  const text = document.getElementById('reviewTextInput').value.trim();

  if (!text) {
    showToast('Please type your review comments.', 'danger');
    return;
  }

  state.currentBookingDoctor.reviews.unshift({
    id: 'rev-' + Date.now(),
    author: author || 'Patient',
    rating: rating,
    date: 'Just now',
    comment: text
  });

  closeModal();
  showToast('Thank you! Your review has been submitted.', 'success');
  renderDoctorProfile(state.currentBookingDoctor);
}

// ============================================================
// TOAST NOTIFICATIONS
// ============================================================
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast-message ${type === 'success' ? 'success' : type === 'danger' ? 'danger' : ''}`;
  
  let iconSvg = '';
  if (type === 'success') {
    iconSvg = '✓';
  } else if (type === 'danger') {
    iconSvg = '✕';
  } else {
    iconSvg = 'ℹ';
  }

  toast.innerHTML = `
    <span style="font-weight: 800; font-size: 16px; color: ${type === 'success' ? 'var(--status-green)' : type === 'danger' ? 'var(--status-red)' : 'var(--primary-teal)'};">${iconSvg}</span>
    <span style="font-size: 0.9rem; font-weight: 600;">${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
