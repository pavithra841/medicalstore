// Initial sample data for HealthSync
const INITIAL_DOCTORS = [
  {
    id: "dr-gayathri",
    name: "Dr.Gayathri",
    speciality: "Cardiologist",
    hospital: "Apollo Hospital,Chennai",
    rating: 4.9,
    reviewsCount: 400,
    experience: "8+ Years",
    fullExperience: "Specialist in non - Invasive Cardiology and preventive cardiac healthcare with over 12 years of experience.",
    fees: "$500",
    feeAmount: 500,
    languages: "Tamil,Eng",
    gender: "female",
    location: "Chennai",
    specializations: ["Heart Disease", "Hypertension", "Cardiology", "ECG"],
    reviews: [
      {
        id: "rev-1",
        author: "Anita",
        rating: 5,
        date: "2 days ago",
        comment: "Very kind and explain everything clearly"
      },
      {
        id: "rev-2",
        author: "Venkatesh S.",
        rating: 5,
        date: "1 week ago",
        comment: "Dr. Gayathri took great care during my consultation. Highly recommended!"
      }
    ]
  },
  {
    id: "dr-priya",
    name: "Dr Priya Sharma",
    speciality: "General Physician",
    hospital: "Apollo Hospital,Chennai",
    rating: 4.8,
    reviewsCount: 120,
    experience: "7+ years",
    fullExperience: "Experienced General Physician providing comprehensive preventive health checks and chronic care management.",
    fees: "$350",
    feeAmount: 350,
    languages: "English,Hindi,Tamil",
    gender: "female",
    location: "Chennai",
    specializations: ["Preventive Health", "Diabetes Care", "Fever & Infection", "Hypertension"],
    reviews: [
      {
        id: "rev-3",
        author: "Ravi Kumar",
        rating: 5,
        date: "3 weeks ago",
        comment: "Very polite and accurate diagnosis. Felt comfortable throughout."
      }
    ]
  },
  {
    id: "dr-arjun",
    name: "Dr Arjun Mehta",
    speciality: "Cardiologist",
    hospital: "City Care Hospital, Chennai",
    rating: 4.6,
    reviewsCount: 176,
    experience: "8+ years",
    fullExperience: "Consultant Cardiologist specializing in echocardiography, heart failure prevention, and coronary rehabilitation.",
    fees: "$450",
    feeAmount: 450,
    languages: "English,Hindi",
    gender: "male",
    location: "Chennai",
    specializations: ["Echocardiography", "Heart Disease", "Cholesterol Management"],
    reviews: [
      {
        id: "rev-4",
        author: "Siddharth N.",
        rating: 4,
        date: "1 month ago",
        comment: "Insightful advice on lifestyle modifications for heart health."
      }
    ]
  },
  {
    id: "dr-kavita",
    name: "Dr kavita",
    speciality: "Gynecologist",
    hospital: "Apollo Hospital,Chennai",
    rating: 4.7,
    reviewsCount: 196,
    experience: "8+ years",
    fullExperience: "Senior Obstetrician and Gynecologist dedicated to women's reproductive health, prenatal guidance and laparoscopic care.",
    fees: "$400",
    feeAmount: 400,
    languages: "Tamil,English",
    gender: "female",
    location: "Chennai",
    specializations: ["Prenatal Care", "Women's Health", "PCOS Management", "Ultrasound"],
    reviews: [
      {
        id: "rev-5",
        author: "Deepika M.",
        rating: 5,
        date: "2 weeks ago",
        comment: "Very comforting and patiently answered all my questions."
      }
    ]
  },
  {
    id: "dr-suresh",
    name: "Dr Suresh Nair",
    speciality: "Neurologist",
    hospital: "City Care Hospital, Chennai",
    rating: 4.9,
    reviewsCount: 215,
    experience: "10+ years",
    fullExperience: "Expert Neurologist focusing on migraine management, nerve disorders, and cognitive healthcare.",
    fees: "$550",
    feeAmount: 550,
    languages: "English,Malayalam,Tamil",
    gender: "male",
    location: "Chennai",
    specializations: ["Migraine & Headache", "Neuropathy", "Stroke Prevention"],
    reviews: [
      {
        id: "rev-6",
        author: "Manoj P.",
        rating: 5,
        date: "5 days ago",
        comment: "Excellent neurologist. My chronic headache has improved drastically."
      }
    ]
  },
  {
    id: "dr-ananya",
    name: "Dr Ananya Sen",
    speciality: "Dermatologist",
    hospital: "Apollo Hospital,Chennai",
    rating: 4.8,
    reviewsCount: 160,
    experience: "6+ years",
    fullExperience: "Consultant Dermatologist specializing in clinical dermatology, acne treatments, and hair & scalp therapies.",
    fees: "$380",
    feeAmount: 380,
    languages: "English,Hindi,Tamil",
    gender: "female",
    location: "Chennai",
    specializations: ["Acne & Scars", "Allergies", "Skin Health", "Hair Fall"],
    reviews: [
      {
        id: "rev-7",
        author: "Pooja V.",
        rating: 5,
        date: "1 month ago",
        comment: "Very gentle and prescribed the exact treatment needed."
      }
    ]
  },
  {
    id: "dr-ramesh",
    name: "Dr Ramesh Patel",
    speciality: "Pediatrics",
    hospital: "Children's Clinic, Chennai",
    rating: 4.9,
    reviewsCount: 310,
    experience: "9+ years",
    fullExperience: "Compassionate Pediatrician focusing on newborn care, developmental milestones, and pediatric vaccinations.",
    fees: "$350",
    feeAmount: 350,
    languages: "English,Gujarati,Tamil",
    gender: "male",
    location: "Chennai",
    specializations: ["Child Development", "Vaccinations", "Pediatric Nutrition"],
    reviews: [
      {
        id: "rev-8",
        author: "Karthik B.",
        rating: 5,
        date: "3 days ago",
        comment: "Kids love Dr. Ramesh! Always friendly, patient and reassuring."
      }
    ]
  }
];

const INITIAL_APPOINTMENTS = {
  upcoming: [
    {
      id: "apt-101",
      doctorId: "dr-gayathri",
      doctorName: "Dr.Gayathri",
      speciality: "Cardiologist",
      hospital: "Apollo Hospital,Chennai",
      rating: "4.9 (400 reviews)",
      date: "Sat, 24 Nov 2026",
      time: "10:30 AM",
      type: "In-Clinic-Visit",
      reason: "Routine check-up",
      status: "Confirmed",
      canReschedule: true,
      canCancel: true
    }
  ],
  past: [
    {
      id: "apt-201",
      doctorId: "dr-priya",
      doctorName: "Dr Priya Sharma",
      speciality: "General Physician",
      hospital: "Apollo Hospital,Chennai",
      date: "12 Oct 2025",
      time: "11:00 AM",
      type: "In-Clinic-Visit",
      status: "Completed"
    },
    {
      id: "apt-202",
      doctorId: "dr-kavita",
      doctorName: "Dr kavita",
      speciality: "Gynecologist",
      hospital: "Apollo Hospital,Chennai",
      date: "18 Nov 2025",
      time: "04:00 PM",
      type: "In-Clinic-Visit",
      status: "Cancelled"
    }
  ]
};

const INITIAL_NOTIFICATIONS = [
  {
    id: "notif-1",
    title: "Appointment Tomorrow",
    message: "Reminder: You have a scheduled appointment with Dr. Gayathri at 10:30 AM.",
    time: "2 hours ago",
    unread: true,
    icon: "calendar"
  },
  {
    id: "notif-2",
    title: "Medication Due",
    message: "Afternoon dosage for Blood Pressure support is due at 02:00 PM.",
    time: "4 hours ago",
    unread: true,
    icon: "pill"
  },
  {
    id: "notif-3",
    title: "Lab Report Uploaded",
    message: "Your Lipid Profile results from Apollo Hospital are now ready to view.",
    time: "Yesterday",
    unread: false,
    icon: "file"
  }
];

const INITIAL_HEALTH_RECORDS = [
  {
    id: "rec-1",
    title: "Cardiac Health & ECG Report",
    doctor: "Dr.Gayathri",
    hospital: "Apollo Hospital,Chennai",
    date: "14 Oct 2026",
    category: "Lab Reports",
    type: "PDF Document",
    size: "1.4 MB",
    summary: "Normal sinus rhythm, heart rate 72 bpm. Blood pressure within optimal parameters (120/78 mmHg)."
  },
  {
    id: "rec-2",
    title: "Complete Blood Profile & Lipid Panel",
    doctor: "Dr Priya Sharma",
    hospital: "Apollo Hospital,Chennai",
    date: "05 Sep 2026",
    category: "Lab Reports",
    type: "PDF Document",
    size: "2.1 MB",
    summary: "HDL 55 mg/dL, LDL 98 mg/dL, Total Cholesterol 174 mg/dL. All markers balanced."
  },
  {
    id: "rec-3",
    title: "Prescription - Preventive Cardiology",
    doctor: "Dr.Gayathri",
    hospital: "Apollo Hospital,Chennai",
    date: "14 Oct 2026",
    category: "Prescriptions",
    type: "Digital Prescription",
    size: "820 KB",
    summary: "Atorvastatin 10mg (once nightly), CoQ10 supplement (morning after breakfast)."
  },
  {
    id: "rec-4",
    title: "Seasonal Flu Vaccination Certificate",
    doctor: "Dr Priya Sharma",
    hospital: "Apollo Hospital,Chennai",
    date: "10 Jun 2026",
    category: "Vaccinations",
    type: "Certificate",
    size: "540 KB",
    summary: "Influenza Quadrivalent Vaccine administered. Next booster recommended in June 2027."
  }
];

const USER_PROFILE = {
  name: "yoga",
  fullName: "Yoga Natarajan",
  email: "yoga.healthsync@example.com",
  phone: "+91 98401 23456",
  age: 28,
  gender: "Male",
  bloodGroup: "B+",
  height: "176 cm",
  weight: "72 kg",
  emergencyContact: "+91 98409 87654 (Sister)",
  allergies: "Penicillin, Peanuts (Mild)",
  city: "Chennai, Tamil Nadu"
};
