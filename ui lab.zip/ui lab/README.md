# HealthSync - Healthcare & Doctor Appointment Management Portal

A full-fledged, pixel-perfect healthcare web application crafted in pure HTML5, CSS3, and modern JavaScript, faithfully reproducing the exact UI screens and interactions from the HealthSync design specification.

---

## 🚀 How to Run in Visual Studio Code

You can run this project effortlessly in **VS Code** without installing Node.js, npm, or any backend dependencies:

### Method 1: Using VS Code Live Server (Recommended)
1. Open Visual Studio Code.
2. Go to **File** > **Open Folder...** and select `F:\ui lab`.
3. In the VS Code Extensions tab (`Ctrl+Shift+X`), install **Live Server** (by Ritwick Dey) if not already installed.
4. Right-click on `index.html` in the file explorer and click **"Open with Live Server"**.
5. Your browser will immediately launch `http://127.0.0.1:5500/index.html`.

### Method 2: Direct Browser Launch
1. Open File Explorer to `F:\ui lab`.
2. Double-click `index.html` to open it in Google Chrome, Microsoft Edge, Brave, or Firefox.

---

## 📱 Implemented Screens & Features

Every single screen from the provided UI mockups has been implemented with functional buttons, transitions, and state management:

### 1. **Desktop - 1 (Home Dashboard)**
- **Personalized Header**: "Hello,yoga 👋" greeting with patient status.
- **Hero Banner**: "Your Health,Our Priority" with doctor silhouette, heart badge, and working "Find Doctor" action.
- **Quick Actions Grid**:
  - 🔍 **Find Doctor** (navigates to Doctor Search)
  - 📅 **Book Appointment** (navigates to Appointments)
  - 📄 **Health Records** (opens Medical Records viewer)
  - 📁 **Upload File** (opens modal to attach medical records)
- **Health Summary Cards**:
  - Upcoming appointment with **Dr. Gayathri** (`07 Sep 2026, 10:30 AM`).
  - Active medication tracker with dosage reminders.

### 2. **Search Doctor (`search doctor`)**
- Real-time search by doctor name, speciality, hospital, or symptoms.
- Filter chips: **Speciality ▾**, **Location ▾**, **Experience ▾**, and **Filter** dialog.
- Top Specialities horizontal category pills (**All**, **Cardiologist**, **Dermatologist**, **Neurologist**, **Gynecologist**, **Pediatrics**).
- Dynamic Doctor Cards:
  - **Dr Priya Sharma** (General Physician - Apollo Hospital, Chennai | ★ 4.8 | 7+ years)
  - **Dr Arjun Mehta** (Cardiologist - City Care Hospital, Chennai | ★ 4.6 | 8+ years)
  - **Dr kavita** (Gynecologist - Apollo Hospital, Chennai | ★ 4.7 | 8+ years)
  - **Dr. Gayathri** (Cardiologist - Apollo Hospital, Chennai | ★ 4.9 | 8+ years)
- Clicking any doctor opens their comprehensive profile.

### 3. **Doctor Profile (`doctor profile`)**
- Doctor identity card with rating, reviews count, and "Book Appointment" CTA.
- 3 Stat Metrics:
  - **Experience**: 8+ Years
  - **Consultation Fees**: $500
  - **Language**: Tamil, Eng
- **About Doctor**: Clinical background and specialties.
- **Specializations Tags**: Heart Disease, Hypertension, Cardiology, ECG.
- **Patient Reviews**: Real reviews (Anita, ★★★★★) with an interactive "+ Add Review" modal.

### 4. **Book Appointment (`book appointment`)**
- Selected doctor summary card with consultation fee display.
- **Select Date**: Carousel picker with day/date/month selection (`Today 25 Aug`, `Thu 26 Aug`, `Fri 27 Aug`, `Sat 28 Aug`, etc.).
- **Select Time**: 6 active slot pills (`09:00 AM`, `10:30 AM`, `12:00 PM`, `02:00 PM`, `04:30 PM`, `06:00 PM`).
- **Visit Type Selector**: Toggle between **Clinic Visit** and **Video Call**.
- **Reason for Visit**: Textarea for clinical concerns.
- **Confirm Booking**: Validates input, saves to active appointments, triggers instant notification, and directs to confirmation.

### 5. **Appointment Confirmation (`appointment confirmation`)**
- Success banner: "Appointment Booked!" with green badge.
- Doctor verification card with security badge ("Your health data is secure").
- Confirmed appointment details: Date, Time, Visit Type, Reason for visit.
- Navigation buttons: "Back Home" and "View Appointment".

### 6. **Appointment History (`appointment history`)**
- Segmented tabs: **Upcoming** & **Past**.
- Upcoming appointment cards:
  - Detailed metadata (Date, Time, Clinic Visit).
  - 📅 **Reschedule Button**: Opens modal to select a new date and time.
  - 🗑️ **Cancel Button**: Confirms cancellation and shifts card to Past Appointments with "Cancelled" status.
- Past appointments with status badges:
  - **Dr Priya Sharma** (● Completed >)
  - **Dr kavita** (● Cancelled >)

---

## ♿ Advanced Accessibility & Utility Suite

The sidebar includes real accessibility switches:
1. **Large Text**: Increases font sizing across the interface.
2. **Reading Space**: Enhances line height and letter spacing for readability.
3. **Read Aloud**: Web Speech Synthesis reads aloud current screen headings and content.
4. **Voice Control**: Voice command assistant and microphone search.
5. **Dark Mode Toggle**: Moon button on top navbar toggles sleek dark theme.
6. **Notifications Panel**: Real-time notifications dropdown with unread badges.

---

## 📁 File Structure

```
F:\ui lab\
│
├── index.html         # Main single-page HTML layout for all 6 screens
├── README.md          # Project guide & instructions
│
├── css\
│   └── style.css      # CSS styling, theme variables, animations, dark mode
│
└── js\
    ├── data.js        # Doctor profiles, past appointments, records dataset
    └── app.js         # Single-page routing, booking engine, voice & accessibility
```
