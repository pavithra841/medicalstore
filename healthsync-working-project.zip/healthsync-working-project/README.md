# HealthSync — Working Local Project

This is a runnable Flask + SQLite project based on the HealthSync screens. It includes the provided doctor illustration and the accessibility controls in the HTML. The database is created automatically when the app starts.

## Features that work
- Splash, onboarding, login, sign-up, OTP verification, forgot password, About, Contact, and dashboard screens.
- SQLite database for accounts and contact messages.
- Passwords stored as SHA-256 hashes (demo-level; use a production password-hashing library before deployment).
- Sign-up validation, unique email checks, 4-digit OTP verification, OTP resend and expiry.
- Login checks credentials and verified status.
- Forgot password generates a reset code and updates the password after verification.
- Contact form stores messages in SQLite.
- Text resizing, accessibility mode, dark mode, microphone voice input (browser support/permission required), and privacy info.
- Images are embedded in the page, so no external image files are required.

## Run on Windows
1. Install Python 3.10 or newer from python.org if it is not installed.
2. Extract this ZIP to a folder.
3. Open Command Prompt in the `healthsync-working-project` folder.
4. Run:
   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```
5. Open `http://127.0.0.1:5000` in Chrome or Edge.

## Demo flow
1. Click Get Started → Continue → Sign Up.
2. Register with a name, email, phone (optional), and password of at least 6 characters.
3. The 4-digit demo OTP is shown on the page because this local project does not send email. Enter it and verify.
4. Use the dashboard or log out. You can log in again with the same credentials.
5. Forgot Password generates a demo reset code; enter it and choose a new password when prompted.
6. Contact messages are saved in `healthsync.db`.

## Important
This is a local academic demonstration, not a production healthcare service. Do not enter real health data or reuse a real password. Email/SMS delivery, Google OAuth, deployment, HTTPS, CSRF protections, rate limiting, and production-grade password hashing are not configured.
