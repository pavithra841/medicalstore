from flask import Flask, jsonify, request, render_template
import sqlite3, os, secrets, hashlib, hmac, re
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'healthsync.db')
app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE,
          phone TEXT DEFAULT '',
          password_hash TEXT NOT NULL,
          verified INTEGER NOT NULL DEFAULT 0,
          otp_hash TEXT,
          otp_expires TEXT,
          reset_hash TEXT,
          reset_expires TEXT,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS contact_messages (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          email TEXT NOT NULL,
          message TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        ''')


def hash_value(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def clean_email(value):
    return (value or '').strip().lower()


def response_error(message, status=400):
    return jsonify({'ok': False, 'message': message}), status


def make_code():
    return f'{secrets.randbelow(9000) + 1000}'


@app.get('/')
def home():
    return render_template('index.html')


@app.get('/api/health')
def health():
    return jsonify({'ok': True, 'service': 'HealthSync API'})


@app.post('/api/signup')
def signup():
    data = request.get_json(silent=True) or {}
    name = (data.get('name') or '').strip()
    email = clean_email(data.get('email'))
    password = data.get('password') or ''
    phone = (data.get('phone') or '').strip()
    if len(name) < 2:
        return response_error('Please enter your full name.')
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
        return response_error('Please enter a valid email address.')
    if len(password) < 6:
        return response_error('Password must contain at least 6 characters.')
    code = make_code()
    now = datetime.utcnow()
    try:
        with db() as con:
            con.execute('''INSERT INTO users(name,email,phone,password_hash,verified,otp_hash,otp_expires,created_at)
                         VALUES(?,?,?,?,0,?,?,?)''',
                        (name, email, phone, hash_value(password), hash_value(code),
                         (now + timedelta(minutes=10)).isoformat(), now.isoformat()))
    except sqlite3.IntegrityError:
        return response_error('An account already exists for this email. Please log in.', 409)
    # Local demo mode: the code is returned to the browser instead of emailing it.
    return jsonify({'ok': True, 'message': 'Account created. Verify the demo code to continue.', 'demo_code': code, 'email': email})


@app.post('/api/verify-otp')
def verify_otp():
    data = request.get_json(silent=True) or {}
    email, code = clean_email(data.get('email')), (data.get('code') or '').strip()
    with db() as con:
        user = con.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
        if not user:
            return response_error('Account not found. Please sign up again.', 404)
        if user['verified']:
            return jsonify({'ok': True, 'message': 'Email already verified.', 'name': user['name'], 'email': email})
        if not user['otp_hash'] or not user['otp_expires'] or datetime.fromisoformat(user['otp_expires']) < datetime.utcnow():
            return response_error('This code has expired. Tap Resend OTP for a new code.')
        if not hmac.compare_digest(user['otp_hash'], hash_value(code)):
            return response_error('That code is incorrect. Please try again.')
        con.execute('UPDATE users SET verified=1, otp_hash=NULL, otp_expires=NULL WHERE email=?', (email,))
    return jsonify({'ok': True, 'message': 'Email verified successfully.', 'name': user['name'], 'email': email})


@app.post('/api/resend-otp')
def resend_otp():
    data = request.get_json(silent=True) or {}
    email = clean_email(data.get('email'))
    code = make_code()
    with db() as con:
        user = con.execute('SELECT verified FROM users WHERE email=?', (email,)).fetchone()
        if not user:
            return response_error('Account not found.', 404)
        if user['verified']:
            return response_error('This account is already verified.')
        con.execute('UPDATE users SET otp_hash=?, otp_expires=? WHERE email=?',
                    (hash_value(code), (datetime.utcnow()+timedelta(minutes=10)).isoformat(), email))
    return jsonify({'ok': True, 'message': 'A new demo code was generated.', 'demo_code': code})


@app.post('/api/login')
def login():
    data = request.get_json(silent=True) or {}
    email, password = clean_email(data.get('email')), data.get('password') or ''
    with db() as con:
        user = con.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
    if not user or not hmac.compare_digest(user['password_hash'], hash_value(password)):
        return response_error('Email or password is incorrect.')
    if not user['verified']:
        return response_error('Please verify your email first. Sign up again only if you do not already have an account.')
    return jsonify({'ok': True, 'message': 'Signed in successfully.', 'name': user['name'], 'email': email})


@app.post('/api/reset-request')
def reset_request():
    data = request.get_json(silent=True) or {}
    email = clean_email(data.get('email'))
    code = make_code()
    with db() as con:
        user = con.execute('SELECT id FROM users WHERE email=?', (email,)).fetchone()
        if not user:
            return response_error('No account was found for this email. Please create an account first.', 404)
        con.execute('UPDATE users SET reset_hash=?, reset_expires=? WHERE email=?',
                    (hash_value(code), (datetime.utcnow()+timedelta(minutes=10)).isoformat(), email))
    return jsonify({'ok': True, 'message': 'Demo reset code generated. No email was sent.', 'demo_code': code, 'email': email})


@app.post('/api/reset-password')
def reset_password():
    data = request.get_json(silent=True) or {}
    email, code, password = clean_email(data.get('email')), (data.get('code') or '').strip(), data.get('password') or ''
    if len(password) < 6:
        return response_error('New password must contain at least 6 characters.')
    with db() as con:
        user = con.execute('SELECT reset_hash,reset_expires FROM users WHERE email=?', (email,)).fetchone()
        if not user:
            return response_error('Account not found.', 404)
        if not user['reset_hash'] or not user['reset_expires'] or datetime.fromisoformat(user['reset_expires']) < datetime.utcnow():
            return response_error('Reset code expired. Request a new code.')
        if not hmac.compare_digest(user['reset_hash'], hash_value(code)):
            return response_error('Reset code is incorrect.')
        con.execute('UPDATE users SET password_hash=?, reset_hash=NULL, reset_expires=NULL WHERE email=?', (hash_value(password), email))
    return jsonify({'ok': True, 'message': 'Password updated. You can now sign in.'})


@app.post('/api/contact')
def contact():
    data = request.get_json(silent=True) or {}
    name, email, message = (data.get('name') or '').strip(), clean_email(data.get('email')), (data.get('message') or '').strip()
    if len(name) < 2 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email) or len(message) < 3:
        return response_error('Please enter your name, a valid email, and a message.')
    with db() as con:
        con.execute('INSERT INTO contact_messages(name,email,message,created_at) VALUES(?,?,?,?)',
                    (name, email, message, datetime.utcnow().isoformat()))
    return jsonify({'ok': True, 'message': 'Your message has been saved successfully.'})


if __name__ == '__main__':
    init_db()
    print('\nHealthSync is starting at http://127.0.0.1:5000')
    print('Demo note: OTP and password-reset codes appear on screen; no email is sent.\n')
    app.run(host='127.0.0.1', port=5000, debug=False)
