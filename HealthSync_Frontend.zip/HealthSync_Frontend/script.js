const screens = [...document.querySelectorAll('.screen')];
const toast = document.getElementById('toast');

function showScreen(id) {
  const target = document.getElementById(id);
  if (!target) return;
  screens.forEach(screen => screen.classList.toggle('active', screen.id === id));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function notify(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => toast.classList.remove('show'), 2600);
}
document.addEventListener('click', event => {
  const nav = event.target.closest('[data-screen]');
  if (nav) showScreen(nav.dataset.screen);
  const toggle = event.target.closest('[data-toggle]');
  if (toggle) {
    const input = document.getElementById(toggle.dataset.toggle);
    input.type = input.type === 'password' ? 'text' : 'password';
    toggle.setAttribute('aria-label', input.type === 'password' ? 'Show password' : 'Hide password');
  }
});

document.getElementById('loginForm').addEventListener('submit', event => {
  event.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const message = document.getElementById('loginMessage');
  message.className = 'form-message';
  message.textContent = 'Demo only: your form is valid. Connect a backend to authenticate users.';
  notify(`Welcome back, ${email}! (Demo mode)`);
});
document.getElementById('signupForm').addEventListener('submit', event => {
  event.preventDefault();
  const password = document.getElementById('signupPassword').value;
  const confirm = document.getElementById('confirmPassword').value;
  const message = document.getElementById('signupMessage');
  if (password !== confirm) {
    message.className = 'form-message error';
    message.textContent = 'Passwords do not match. Please try again.';
    return;
  }
  message.className = 'form-message';
  message.textContent = 'Account details look good. Demo OTP: enter any four digits.';
  showScreen('otp');
  notify('Account details accepted. Verify your email (demo).');
});
const otpInputs = [...document.querySelectorAll('.otp-inputs input')];
otpInputs.forEach((input, index) => {
  input.addEventListener('input', () => {
    input.value = input.value.replace(/\D/g, '').slice(0, 1);
    if (input.value && otpInputs[index + 1]) otpInputs[index + 1].focus();
  });
  input.addEventListener('keydown', event => {
    if (event.key === 'Backspace' && !input.value && otpInputs[index - 1]) otpInputs[index - 1].focus();
  });
  input.addEventListener('paste', event => {
    const digits = (event.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 4);
    if (digits) {
      event.preventDefault();
      digits.split('').forEach((digit, i) => { if (otpInputs[i]) otpInputs[i].value = digit; });
      otpInputs[Math.min(digits.length, 3)].focus();
    }
  });
});
document.getElementById('otpForm').addEventListener('submit', event => {
  event.preventDefault();
  const code = otpInputs.map(input => input.value).join('');
  const message = document.getElementById('otpMessage');
  if (code.length !== 4) {
    message.className = 'form-message error';
    message.textContent = 'Please enter all four digits.';
    return;
  }
  message.className = 'form-message';
  message.textContent = 'OTP accepted in demo mode. Your account is verified!';
  notify('Email verified successfully (demo).');
  setTimeout(() => showScreen('login'), 1400);
});
document.getElementById('resendOtp').addEventListener('click', () => {
  otpInputs.forEach(input => input.value = '');
  otpInputs[0].focus();
  notify('A new OTP would be sent by your backend.');
});
document.getElementById('forgotForm').addEventListener('submit', event => {
  event.preventDefault();
  const email = document.getElementById('forgotEmail').value.trim();
  const message = document.getElementById('forgotMessage');
  message.className = 'form-message';
  message.textContent = `If ${email} is registered, a reset link would be sent.`;
  notify('Password reset flow completed in demo mode.');
});
