const screens = [...document.querySelectorAll('.screen')];
const screenButtons = [...document.querySelectorAll('.screen-switcher button')];
const backButton = document.getElementById('backButton');
const skipButton = document.getElementById('skipButton');
const headerAction = document.getElementById('headerAction');
const toast = document.getElementById('toast');
let previousScreen = 'login';

function showScreen(id) {
  const target = document.getElementById(id);
  if (!target) return;
  const current = document.querySelector('.screen.active');
  if (current && current.id !== id) previousScreen = current.id;
  screens.forEach(s => s.classList.toggle('active', s.id === id));
  screenButtons.forEach(b => b.classList.toggle('active', b.dataset.screen === id));
  const isSplash = id === 'splash';
  const isOnboarding = id === 'onboarding';
  backButton.style.visibility = (isSplash || isOnboarding) ? 'hidden' : 'visible';
  skipButton.style.display = isOnboarding ? 'block' : 'none';
  headerAction.style.visibility = isSplash ? 'hidden' : 'visible';
  document.querySelector('.mini-brand').style.visibility = isSplash ? 'hidden' : 'visible';
  document.querySelector('.app-header').style.display = isSplash ? 'none' : 'grid';
}
function notify(text) {
  toast.textContent = text;
  toast.classList.add('show');
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => toast.classList.remove('show'), 2600);
}
document.addEventListener('click', e => {
  const nav = e.target.closest('[data-screen]');
  if (nav) showScreen(nav.dataset.screen);
});
screenButtons.forEach(button => button.addEventListener('click', () => showScreen(button.dataset.screen)));
backButton.addEventListener('click', () => {
  const active = document.querySelector('.screen.active')?.id;
  if (active === 'otp') showScreen('signup');
  else if (active === 'forgot') showScreen('login');
  else showScreen('login');
});
headerAction.addEventListener('click', () => notify('Accessibility options can be connected here.'));
document.getElementById('loginForm').addEventListener('submit', e => {
  e.preventDefault();
  document.getElementById('loginMessage').textContent = 'Demo only: form validated. Connect a backend to sign in.';
  notify('Login form submitted (demo).');
});
document.getElementById('signupForm').addEventListener('submit', e => {
  e.preventDefault();
  document.getElementById('signupMessage').textContent = 'Details accepted in demo mode. Enter any four digits on the OTP screen.';
  showScreen('otp');
  notify('Demo registration successful. Verify your OTP.');
});
const otpInputs = [...document.querySelectorAll('.otp-inputs input')];
otpInputs.forEach((input, i) => {
  input.addEventListener('input', () => {
    input.value = input.value.replace(/\D/g, '').slice(0, 1);
    if (input.value && otpInputs[i + 1]) otpInputs[i + 1].focus();
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Backspace' && !input.value && otpInputs[i - 1]) otpInputs[i - 1].focus();
  });
  input.addEventListener('paste', e => {
    const digits = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 4);
    if (!digits) return;
    e.preventDefault();
    digits.split('').forEach((d, n) => { if (otpInputs[n]) otpInputs[n].value = d; });
    otpInputs[Math.min(digits.length, 3)].focus();
  });
});
document.getElementById('otpForm').addEventListener('submit', e => {
  e.preventDefault();
  const code = otpInputs.map(input => input.value).join('');
  if (code.length !== 4) {
    document.getElementById('otpMessage').textContent = 'Please enter all four digits.';
    document.getElementById('otpMessage').classList.add('error');
    return;
  }
  document.getElementById('otpMessage').textContent = 'OTP verified in demo mode.';
  notify('OTP verified (demo).');
  setTimeout(() => showScreen('login'), 1200);
});
document.getElementById('resendOtp').addEventListener('click', () => {
  otpInputs.forEach(input => input.value = '');
  otpInputs[0].focus();
  notify('A new OTP would be sent by your backend.');
});
document.getElementById('forgotForm').addEventListener('submit', e => {
  e.preventDefault();
  const email = document.getElementById('forgotEmail').value.trim();
  document.getElementById('forgotMessage').textContent = `If ${email} is registered, a reset link would be sent.`;
  notify('Password reset submitted (demo).');
});
document.getElementById('loginGoogle').addEventListener('click', () => notify('Google sign-in requires OAuth setup.'));
document.getElementById('signupGoogle').addEventListener('click', () => notify('Google sign-up requires OAuth setup.'));
showScreen('splash');
