const screens = [...document.querySelectorAll('.screen')];
const stepNames = {
  splash:['WELCOME','01 / 06'],
  onboarding:['GET TO KNOW US','02 / 06'],
  login:['SIGN IN','03 / 06'],
  signup:['CREATE ACCOUNT','04 / 06'],
  otp:['VERIFICATION','05 / 06'],
  forgot:['RECOVER ACCOUNT','06 / 06']
};
const toast = document.getElementById('toast');
function showScreen(id){
  if(!document.getElementById(id)) return;
  screens.forEach(screen=>screen.classList.toggle('active',screen.id===id));
  document.getElementById('stepLabel').textContent=stepNames[id][0];
  document.getElementById('stepNumber').textContent=stepNames[id][1];
  window.scrollTo({top:0,behavior:'smooth'});
}
function notify(message){
  toast.textContent=message;toast.classList.add('show');
  clearTimeout(notify.timer);notify.timer=setTimeout(()=>toast.classList.remove('show'),2200);
}
document.addEventListener('click',event=>{
  const button=event.target.closest('[data-screen]');
  if(button){showScreen(button.dataset.screen);}
});
document.getElementById('resend').addEventListener('click',()=>notify('Demo: a new verification code would be sent here.'));
document.querySelectorAll('.otp-boxes button').forEach((box,index)=>{
  box.addEventListener('click',()=>{
    const digit=prompt(`Enter OTP digit ${index+1} (optional demo)`);
    if(digit===null)return;
    if(/^\d$/.test(digit)){box.textContent=digit;}else{notify('Enter one digit, or leave it blank for this demo.');}
  });
});
showScreen('splash');
