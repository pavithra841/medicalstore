const screens=[...document.querySelectorAll('.screen')];
const navButtons=[...document.querySelectorAll('.screen-nav button')];
const backBtn=document.getElementById('backBtn');
const toast=document.getElementById('toast');
let current='home';
const routes={home:'home',doctor:'search',search:'home',book:'doctor',confirmation:'book',history:'home'};
function showScreen(id){
 if(!document.getElementById(id))return;
 current=id;
 screens.forEach(s=>s.classList.toggle('active',s.id===id));
 navButtons.forEach(b=>b.classList.toggle('active',b.dataset.screen===id));
 backBtn.style.visibility=id==='home'?'hidden':'visible';
 document.querySelector('.appbar-title').innerHTML=(id==='home'?'<span class="tiny-heart">♡</span> HealthSync':({doctor:'Doctor Profile',search:'Search Doctor',book:'Book Appointment',confirmation:'Appointment Confirmation',history:'Appointment History'}[id]||'HealthSync'));
}
function notify(message){toast.textContent=message;toast.classList.add('show');clearTimeout(notify.timer);notify.timer=setTimeout(()=>toast.classList.remove('show'),2200)}
document.addEventListener('click',e=>{
 const button=e.target.closest('[data-screen]');
 if(button)showScreen(button.dataset.screen);
});
backBtn.addEventListener('click',()=>showScreen(routes[current]||'home'));
document.getElementById('favorite').addEventListener('click',e=>{e.currentTarget.textContent=e.currentTarget.textContent==='♡'?'♥':'♡';notify(e.currentTarget.textContent==='♥'?'Doctor added to favourites':'Removed from favourites')});
document.querySelectorAll('.date-list button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.date-list button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')}));
document.querySelectorAll('.time-list button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.time-list button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')}));
document.querySelectorAll('.visit-list button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.visit-list button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')}));
document.querySelectorAll('.filters button').forEach(b=>b.addEventListener('click',()=>{
 document.querySelectorAll('.filters button').forEach(x=>x.classList.remove('chosen'));b.classList.add('chosen');
 const filter=b.dataset.filter;
 document.querySelectorAll('.doctor-card').forEach(card=>card.hidden=filter!=='All'&&!card.dataset.specialty.toLowerCase().includes(filter.toLowerCase()));
}));
document.getElementById('doctorSearch').addEventListener('input',e=>{
 const q=e.target.value.toLowerCase();
 document.querySelectorAll('.doctor-card').forEach(card=>card.hidden=!(card.dataset.name+' '+card.dataset.specialty).toLowerCase().includes(q));
});
document.getElementById('voiceSearch').addEventListener('click',()=>notify('Voice search can be connected later.'));
document.querySelectorAll('.tabs button').forEach(b=>b.addEventListener('click',()=>{
 document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');
 const past=b.dataset.tab==='past';document.getElementById('upcomingPanel').hidden=past;document.getElementById('pastPanel').hidden=!past;
}));
document.querySelectorAll('.cancel').forEach(b=>b.addEventListener('click',()=>{const card=b.closest('.history-card');const badge=card.querySelector('.history-top em');badge.textContent='Cancelled';badge.className='cancelled';b.disabled=true;b.textContent='Cancelled';notify('Appointment cancelled in demo mode.')}));
showScreen('home');
